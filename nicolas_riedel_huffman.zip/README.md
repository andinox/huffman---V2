Pour lancer le programme.

Le code de test est dans le App la function main.
environement maven.
Codé sur VSCODE

Lib utilisé pour lire le ODS
https://github.com/miachm/SODS


Pour lancer le code depuis VSCODE
avoir l'extention "Extension Pack for Java"
et lancer avec le run au debut du main dans App.java.

Bien avoir la variable d'environement JAVA_HOME de défini.